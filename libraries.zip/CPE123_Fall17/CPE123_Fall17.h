
// Writing by Hugh Smith - 9/2016
//  version 4
//
// Timer, LED, Button and support functions 

#ifndef MYCLASSES4_H
#define MYCLASSES4_H

#include "Arduino.h"

#define MAX_PRINTF 150

// support functions 
void printLibVersion(Stream & aStream = Serial);
void setupMessage(const char * file, char * message = NULL, Stream & aStream = Serial);
void serialPrintf(const char * format, ...);
void serialPrintf(Stream & aStream, const char * format, ...);
void printVolts(int aPin, char * voltageBuf = NULL, Stream & aStream = Serial);


class MSTimer {
 
 private:
	// MSTimer enums
	enum {MSTIMER_DONE, DELAYING};

	unsigned long msDuration;
	unsigned long start_time;
	int msDelayState;
	void reset(uint32_t ms_duration);

  public: 
	MSTimer();
	MSTimer(uint32_t ms_duration);
	void set(uint32_t ms_duration);
	unsigned long remaining();
	int done();

};



class Led {
  private:
  
	// Led enums 
	enum {ON_BLINK, OFF_BLINK_SHORT, OFF_BLINK_LONG, BLINKING_OFF};
	
    unsigned char pin;
	
    unsigned long durationOn;
	unsigned long shortDurationOff;
	unsigned long longDurationOff;
    int blinkState;
	int numRepeatBlinks;
	int repeatCount;
    MSTimer ledDelay;
		        
    // only used internally
	void initPin();
	void ledSetOn();
 
  public:
    Led(const int ledPin);
	Led();
	void initLed(const int aPin);

    void on();
    void off();
    void update();
	void numberedBlinkOn(int repeatsOn = 2, uint32_t durationOn = 500, uint32_t shortDurationOff = 200, uint32_t longDurationOff = 1000);
    void blinkOn(unsigned long aDuration = 1000);
	
};




class Button
{
		
 private:
	// Button enums
	enum {PUSH_START, PUSH_WAITING};
	enum {DUR_START, DUR_WAITING, DUR_TIME};
 
	int pin;

	// isPushed variables
	int pushState;
	MSTimer pushTimer;

	// duration variables
	int durState;
	unsigned long durStart;
	MSTimer durTimer;

	public:
	Button(int buttonPin);
	int wasPushed(int pushWait = 500);
	int isCurrentlyPushed();
	unsigned long duration();
	};
	
	
// printing multiple data items (I could collapse these into one function except for the newline feature)

template<typename T1, typename T2> void printPair(T1 aVar1, T2 aVar2, int newLine = true); 
template<typename T1, typename T2> void printPair(T1 aVar1, T2 aVar2, int newLine)
{
	printPair(Serial, aVar1, aVar2, newLine);
	
}

template<typename T1, typename T2> void printPair(Stream & aStream, T1 aVar1, T2 aVar2, int newLine = true);
template<typename T1, typename T2> void printPair(Stream & aStream, T1 aVar1, T2 aVar2, int newLine)
{
	aStream.print(aVar1);
	aStream.print(aVar2);
	if (newLine)
		aStream.println();
}

template<typename T1, typename T2> void print2(T1 aVar1, T2 aVar2, int newLine = true);
template<typename T1, typename T2> void print2(T1 aVar1, T2 aVar2, int newLine)
{
	printPair(Serial, aVar1, aVar2, newLine);
}

template<typename T1, typename T2, typename T3> void print3(T1 aVar1, T2 aVar2, T3 aVar3, int newLine = true);
template<typename T1, typename T2, typename T3> void print3(T1 aVar1, T2 aVar2, T3 aVar3, int newLine)
{
	printPair(Serial, aVar1, aVar2, false);
	printPair(Serial, aVar3, "", newLine);
}

template<typename T1, typename T2, typename T3, typename T4> void print4(T1 aVar1, T2 aVar2, T3 aVar3, T4 aVar4, int newLine = true);
template<typename T1, typename T2, typename T3, typename T4> void print4(T1 aVar1, T2 aVar2, T3 aVar3, T4 aVar4, int newLine)
{
	printPair(Serial, aVar1, aVar2, false);
	printPair(Serial, aVar3, aVar4, newLine);
}


#endif

